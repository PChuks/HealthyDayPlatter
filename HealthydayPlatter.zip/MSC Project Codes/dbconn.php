<?php
	//Step1: Database connect
	define('DB_NAME', 'unn_w20033453');
	define('DB_USER', 'unn_w20033453');
	define('DB_PASSWORD', 'Star2@gate');
	define('DB_HOST', 'localhost');
	$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
	if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
	}
	echo "Connect successfully";
	
?>