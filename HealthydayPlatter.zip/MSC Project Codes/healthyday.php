<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
  header("location: hdlogin.html");
  exit; // prevent further execution, should there be more code that follows
}
?>
<html lang="en">
  <head>
    <link rel="stylesheet" href="hday.css">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Healthy Day Platter</title>
  </head>
  <body>
     <section>
        <h1>The Healthy Day Platter</h1>
<!--Describes the top navigation bar--> 
            <div class="topnav">
              <a class="active" href="healthyday.html">Home</a>
              <a href="#">My Social-Worker</a>
              <a href="#">Records</a>
              <a href="hdlogout.php" class = "split">Logout</a>
            </div>

<!--Describes the main image--> 

          <img class = "main-image" src="healthymind1.png" alt="play time image" width="200" height="200"/>
          <div class = "quote">
            <p>
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
              sed do eiusmod tempor incididunt ut labore et dolore magna
              aliqua. Ut enim ad minim veniam, quis nostrud exercitation
              ullamco laboris nisi ut aliquip ex ea commodo consequat. 
              Duis aute irure dolor in reprehenderit in voluptate velit 
              esse cillum dolore eu fugiat nulla pariatur. Excepteur 
              sint occaecat cupidatat non proident, sunt in culpa qui 
              officia deserunt mollit anim id est laborum."                                                      
            </p>
          </div>

     </section>
     <section>
     <form action="hdPhysical.php" method="post">
        <div class="flex-container">
          <div id ="profile"><img src = "profile.jpeg" alt = "user picture" width = "450" height = "400"></div>
          <div>
            <ul style="list-style-type:none;">
              <li>Name: Chukwudi Nnadi</li>
              <br></b>
              <li>Age: 12</li>
              <br></b>
              <li>Address: 12 Magnolia Drive, Newcastle Upon Tyne, NE53DG</li>
              <br></b>
              <li>Guardian: Mark Spencer</li>
            </ul>
          </div>  
        </div>
</form>
      </section>
      <section>
     <h2>The 7 Platters</h2>
<!--Describes the quote-->  
    <container>
<!--Gives information on physical time--> 
        <form action="hdPhysical.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img src="physical.png" alt="physical time image" width="150" height="150"/></summary>
              <p>When we move our bodies, aerobically if 
                medically possible, we strengthen 
                the brain in many ways
              </p> 
<!--Describes the detail section for the physical time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>

  <!--Gives information on focus time--> 
  <form action="hdFocus.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img src="focus.png" alt="focus time image" width="150" height="150"/></summary>
              <p>When we closely focus on tasks in a goal-oriented way,
                   we take on challenges that make deep connections in the brain.
              </p>
<!--Describes the detail section for focus time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>

<!--Gives information on play time--> 
<form action="hdPlay.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img  src="play.png" alt="play time image" width="150" height="150"/></summary>
              <p>When we allow ourselves to be spontaneous or
                creative, playfully enjoying novel experiences,
                we help make new connections in the brain.
              </p>
<!--Describes the detail section for play time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>
  
<!--Gives information on down time--> 
<form action="hdDowntime.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img  src="downtime.png" alt="downtime time image" width="150" height="150"/></summary>
              <p>When we are non-focused, without any specific goal,
                and let our mind wander or simply relax, we 
                help the brain recharge.
              </p>
<!--Describes the detail section for downtime-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>
<!--Gives information on Time in--> 
        <form action="hdTimein.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img  src="timein.png" alt="time-in time image" width="150" height="150"/></summary>
              <p>When we quietly reflect internally, focusing on
                sensations, images, feelings and thoughts, 
                we help to better integrate the brain.
              </p>
<!--Describes the detail section for time in-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>
      
<!--Gives information on connect time--> 
<form action="hdConnect.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
            <summary><img  src="connect.png" alt="play time image" width="150" height="150"/></summary>
              <p>When we connect with other people, ideally in person,
                and when we take time to appreciate our connection 
                to the natural world around us, we activate and reinforce
                the brain's relational circuitry.
              </p>
<!--Describes the detail section for connect time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>
  
<!--Gives information on sleep time--> 
<form action="hdSleep.php" method="post">
          <details>
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <summary><img  src="sleep.png" alt="sleep time image" width="150" height="150"/></summary>
              <p>When we give the brain the rest it needs,
                we consolidate learning and recover from 
                the experiences of the day.
              </p>
<!--Describes the detail section for sleep time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent">
                    <option value="30 min">30 minutes</option>
                    <option value="1 hour">1 hour </option>
                    <option value="2 hour">1 hours 30 minutes</option>
                    <option value="3 hour">2 hours</option>
                  </select> 
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" >
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details>           
        </form>                               
  <!--Describes the extra  note space-->
      <div class = "textarea">
          <form action="hdNote.php" method="post">
            <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
              <p>
                Use the text box below to talk about your day. Feel free to express yourself, 
                only your social worker can see this.
              </p>
              <textarea rows="4" cols="50" name = "note">
              </textarea>
            </div>  
              <br><br>
                      <button type="submit" class="submitbtn">Submit</button>
                    </div>
              </form>
          </div>
      </section>
</body>
</html>
