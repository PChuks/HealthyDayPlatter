
        <?php
 
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        //Step1: Database connect
	define('DB_NAME', 'unn_w20033453');
	define('DB_USER', 'unn_w20033453');
	define('DB_PASSWORD', 'Star2@gate');
	define('DB_HOST', 'localhost');
	$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
        // Taking all 5 values from the form data(input)
        $username = $_REQUEST['username'];
        $fName= $_REQUEST['fName'];
        $lName = $_REQUEST['lName'];
        $dob = $_REQUEST['dob'];
        $homeAddress= $_REQUEST['homeAddress'];
        $postcode = $_REQUEST['postcode'];
        $gender = $_REQUEST['gender'];
        $guardianName= $_REQUEST['guardianName'];
        $userPassword=$_REQUEST['userPassword'];
     
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO hdRegister  VALUES ('','$username', '$fName', '$lName', '$dob', '$homeAddress', '$postcode', '$gender', 
        '$guardianName', '$userPassword') 
          ";
        if(mysqli_query($conn, $sql)){
            //echo "<h3>data stored in a database successfully."
               // . " Please browse your localhost php my admin"
               // . " to view the updated data</h3>";
                echo "<script type = 'text/javascript'> alert('Data stored in hdRegister table successfully!');
                document.location='http://unn-w20033453.newnumyspace.co.uk/hdregister.html'</script>";
            /*echo nl2br("\n$fName\n $lName\n "
                . "$dob\n $address\n $username");*/
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        // Close connection
        mysqli_close($conn);
        ?>
    