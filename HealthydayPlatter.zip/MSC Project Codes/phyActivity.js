
// Toggle between showing and hiding the dropdown when user clicks on the button
  var openDropdown = null;
  function shareVis(dropDownId) {
    if (openDropdown !== null){
    openDropdown.classList.remove("show");
    }
  var dropdown = document.getElementById(dropDownId);
  dropdown.classList.toggle("show");
  openDropdown = dropdown;
}
  // Close the dropdown if user clicks outside it
  window.onclick = function(event) {
    if (!event.target.matches(".sharebtn") && !event.target.closest(".sharedown-content")) {
      if (openDropdown !== null){
          openDropdown.classList.remove("show");
          openDropdown = null;
        }
      }
    }
  document.getElementById("phyShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  
  document.getElementById("focusShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.getElementById("playShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.getElementById("timeinShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.getElementById("downtimeShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.getElementById("connectShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.getElementById("sleepShareDown").addEventListener("click", function(event) {
    event.stopPropagation();
  });
  document.addEventListener("DOMContentLoaded", function(event) {
    shareVis("phyShareDown");
    shareVis("focusShareDown");
    shareVis("playShareDown")
    shareVis("timeinShareDown")
    shareVis("downtimeShareDown")
    shareVis("connectShareDown")
    shareVis("sleepShareDown")
  });
