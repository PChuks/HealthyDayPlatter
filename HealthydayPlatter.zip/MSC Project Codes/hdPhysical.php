<?php
//Include file that contains code to connect to database
include 'dbconn.php'; 
//
$activityTime= $_REQUEST['activityTime'];
$activityDuration = $_REQUEST['activityDuration'];
$activityDate = $_REQUEST['activityDate'];
$userId = $_REQUEST['userId'];
$activityPerformed = $_REQUEST['activityPerformed'];
//to insert into a table in the database
$sql = "INSERT INTO hdPhysical (userId, activityTime, activityDuration, activityPerformed, activityDate) VALUES 
        ($userId, '$activityTime', '$activityDuration', '$activityPerformed', '$activityDate')";
//Display messgae if data is captured in database
if(mysqli_query($conn, $sql)){
    echo "<script type = 'text/javascript'> alert('Data stored in a database successfully!');
    document.location='myHealthyDay.php'</script>";
} 
//Display messgae if data is not captured in database
else{
    echo "ERROR: Hush! Sorry $sql. "
        . mysqli_error($conn);
}
// Close connection
mysqli_close($conn);
?>
