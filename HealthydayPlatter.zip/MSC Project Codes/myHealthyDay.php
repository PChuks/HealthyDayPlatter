<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
  header("location: healthyDayLogin.html");
  exit; // prevent further execution, should there be more code that follows
}
?>
<html lang="en">
  <head>
    <link rel="stylesheet" href="hDay.css">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Healthy Day Platter</title>
    <script src="phyActivity.js"></script> 
  </head>
  <body>
     <section>
        <h1>The Healthy Day Platter</h1>
<!--Describes the top navigation bar--> 
            <div class="topnav">
              <a class="active" href="healthyday.html">Home</a>
              <a href="hdProfile.php">My Profile</a>
              <a href="#">Records</a>
              <a href="hdlogout.php" class = "split">Logout</a>
            </div>
<!--Describes the main image--> 
          <img class = "main-image" src="hdmain.jpeg" alt="play time image" width="50" height="100"/>
          <div class = "quote">
            <p>
            Daily activities should include a balance of physical activity, sleep, 
            play, social connection, downtime, and time for focused activities such 
            as homework or hobbies. Engaging in regular physical activity, such as 
            sports or outdoor play, can help us maintain a healthy weight, build 
            strength and endurance, and improve our mood. Social connection with 
            family and friends is also important as it helps us feel supported and 
            connected. Downtime, or unstructured free time, allows cus to recharge 
            and pursue our interests. Finally, setting aside focused time for homework
             or other activities can help us achieve our goals and develop valuable skills.                                                    
            </p>
          </div>
     </section>
      <section>
     <h2>The 7 Platters</h2>
<!--Describes the quote--> 
<div class ="phyAct">
  <form action="hdPhysical.php" method="post">
    <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
        <div class="sharedown">
          <p class="name">Physical Time</p>
          <p onclick="shareVis('phyShareDown')" class="sharebtn"><img src="hdphysical.png" alt="physical time image" width="150" height="150"/></p>
            <div id="phyShareDown" class="sharedown-content">
              <p class ="activityDetail">Physical activity is when you move your body by playing games, 
                running, jumping, dancing, or doing sports. It's fun and helps
                 you stay healthy and strong. When you're physically active,
                  you use your muscles and bones, and your heart beats faster. 
                  Remember to always be safe and wear comfortable clothes and 
                  shoes when you're doing physical activity.
              </p> 
<!--Describes the detail section for the physical time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day" required>
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent" required>
                  <option value="0.5">30 minutes</option>
                <option value="1">1 hour </option>
                <option value="1.5">1 hours 30 minutes</option>
                <option value="2">2 hours</option>
                  </select> 
                  <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </div>
        </div>
     </form>

     
     <form action="hdFocus.php" method="post">  
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
  <div class="sharedown">
  
    <p class="name">Focus Time</p>
    <p onclick="shareVis('focusShareDown')" class="sharebtn"><img src="hdfocus.png" alt="focus time image" width="150" height="150"/></p>
      <div id="focusShareDown" class="sharedown-content">
      <p class ="activityDetail">Focus time as it allows us to concentrate on tasks that
        require our full attention, such as homework or reading. Setting aside regular 
        blocks of time for focused activities can help us stay organized and productive, 
        and build important skills like time management and critical thinking. However, 
        it's important to balance focus time with other activities, such as physical activity 
        and downtime, to avoid burnout and promote overall well-being. Engagind and switching
        between different types of activities can help us stay engaged and motivated.
      </p>
<!--Describes the detail section for focus time-->  
      <div class = "activityDetails">
        <p>Use the tabs below to provide details of your activities today</p>
          <label for="time_of_day"><b>Time_of_Day:</b></label>
          <select name="activityTime" id="time_of_day" required>
            <option value="am">AM</option>
            <option value="pm">PM</option>
          </select>
          <br><br>
          <label for="time_spent"><b>Time_Spent:</b></label>
          <select name="activityDuration" id="time_spent" required>
          <option value="0.5">30 minutes</option>
                <option value="1">1 hour </option>
                <option value="1.5">1 hours 30 minutes</option>
                <option value="2">2 hours</option>
          </select> 
          <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
          <br><br>
          <label for="date"><b>Date_of_Activity:</b></label>
          <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
           <br><br>
      </div>
      <br><br>
      <button type="submit" class="submitbtn">Submit</button>
</div>
</div> 
</form>  

<form action="hdPlay.php" method="post">
         
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
<div class="sharedown">
  <p class="name">Play Time</p>
  <p onclick="shareVis('playShareDown')" class="sharebtn"><img src="hdplay.png" alt="play time image" width="150" height="150"/></p>
    <div id="playShareDown" class="sharedown-content">
              <p class ="activityDetail">Play is a fun activity that we love to do,
                It can be anything from running to playing with glue!
                You can play with toys or with friends outside,
                Or make a fort with blankets and pillows to hide!
                Just remember to have fun and let your imagination take flight!
              </p>
<!--Describes the detail section for play time-->  
              <div class = "activityDetails">
                <p>Use the tabs below to provide details of your activities today</p>
                  <label for="time_of_day"><b>Time_of_Day:</b></label>
                  <select name="activityTime" id="time_of_day" required>
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                  </select>
                  <br><br>
                  <label for="time_spent"><b>Time_Spent:</b></label>
                  <select name="activityDuration" id="time_spent" required>
                  <option value="0.5">30 minutes</option>
                <option value="1">1 hour </option>
                <option value="1.5">1 hours 30 minutes</option>
                <option value="2">2 hours</option>
                  </select> 
                   <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
                  <br><br>
                  <label for="date"><b>Date_of_Activity:</b></label>
                  <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
                   <br><br>
              </div>
                  <br><br>
                  <button type="submit" class="submitbtn">Submit</button>
            </details> 
            </div>
            </div>
</form>
            
            
<form action="hdDowntime.php" method="post">
          
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
            <div class="sharedown">
              <p class="name">Downtime</p>
              <p onclick="shareVis('downtimeShareDown')" class="sharebtn"><img src="downtime1.png" alt="time-in image" width="150" height="150"/></p>
                <div id="downtimeShareDown" class="sharedown-content">
            <p class ="activityDetail">Downtime allows us to unwind and recharge. Engaging in 
                unstructured, low-stress activities during downtime can help us reduce stress 
                and improve our mood. Examples of downtime activities include listening to music, 
                drawing, or simply relaxing and doing nothing. Downtime helps prevent burnout and 
                promote overall well-being. A balanced approach to daily activities, including 
                downtime, can help us maintain a healthy and fulfilling lifestyle.
            </p>
<!--Describes the detail section for downtime-->  
            <div class = "activityDetails">
              <p>Use the tabs below to provide details of your activities today</p>
                <label for="time_of_day"><b>Time_of_Day:</b></label>
                <select name="activityTime" id="time_of_day" required>
                  <option value="am">AM</option>
                  <option value="pm">PM</option>
                </select>
                <br><br>
                <label for="time_spent"><b>Time_Spent:</b></label>
                <select name="activityDuration" id="time_spent" required>
                <option value="0.5">30 minutes</option>
                <option value="1">1 hour </option>
                <option value="1.5">1 hours 30 minutes</option>
                <option value="2">2 hours</option>
                </select> 
                <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
                <br><br>
                <label for="date"><b>Date_of_Activity:</b></label>
                <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
                 <br><br>
            </div>
                <br><br>
                <button type="submit" class="submitbtn">Submit</button>
          </details> 
          </div>
          </div>
</form>   

    <!--Gives information on Time in--> 
    <form action="hdTimein.php" method="post">
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
          <div class="sharedown">
            <p class="name">Time-In</p>
            <p onclick="shareVis('timeinShareDown')" class="sharebtn"><img src="timein1.png" alt="time-in image" width="150" height="150"/></p>
              <div id="timeinShareDown" class="sharedown-content">
          <p class ="activityDetail">Time in is a daily activity that encourages us to 
            pause and reflect. It involves finding a quiet and comfortable space to sit
             or lie down, and focusing on one's thoughts and feelings. By practicing "time in" 
             regularly, we can develop greater self-awareness, improve our ability to manage
              stress and emotions, and enhance our overall well-being. It's a simple yet 
              powerful tool that can help us cope with the challenges of growing up, and build 
              lifelong habits of mindfulness and self-care.
          </p>
<!--Describes the detail section for time in-->  
          <div class = "activityDetails">
            <p>Use the tabs below to provide details of your activities today</p>
              <label for="time_of_day"><b>Time_of_Day:</b></label>
              <select name="activityTime" id="time_of_day" required>
                <option value="am">AM</option>
                <option value="pm">PM</option>
              </select>
              <br><br>
              <label for="time_spent"><b>Time_Spent:</b></label>
              <select name="activityDuration" id="time_spent" required>
                <option value="0.5">30 minutes</option>
                <option value="1">1 hour </option>
                <option value="1.5">1 hours 30 minutes</option>
                <option value="2">2 hours</option>
              </select> 
              <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
              <br><br>
              <label for="date"><b>Date_of_Activity:</b></label>
              <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
               <br><br>
          </div>
              <br><br>
              <button type="submit" class="submitbtn">Submit</button>
        </details> 
        </div>
        </div>          
</form>   
      

    <!--Gives information on connect time--> 
<form action="hdConnect.php" method="post">
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
        <div class="sharedown">
          <p class="name">Connect Time</p>
          <p onclick="shareVis('connectShareDown')" class="sharebtn"><img src="connect1.png" alt="connect image" width="150" height="150"/></p>
            <div id="connectShareDown" class="sharedown-content">
        <p class ="activityDetail">Connect time is when we talk, play, or do activities with 
            our family and friends. We can connect with others by doing 
            things we enjoy together, like reading books, playing games,
             or going for walks. When we spend time with others, we can 
             share our thoughts and feelings and learn new things. Connect 
             time is important because it helps us build strong relationships
              with the people we care about. We should try to make time 
              for connect time every day.
        </p>
<!--Describes the detail section for connect time-->  
        <div class = "activityDetails">
          <p>Use the tabs below to provide details of your activities today</p>
            <label for="time_of_day"><b>Time_of_Day:</b></label>
            <select name="activityTime" id="time_of_day" required>
              <option value="am">AM</option>
              <option value="pm">PM</option>
            </select>
            <br><br>
            <label for="time_spent"><b>Time_Spent:</b></label>
            <select name="activityDuration" required id="time_spent" required>
              <option value="0.5">30 minutes</option>
              <option value="1">1 hour </option>
              <option value="1.5">1 hours 30 minutes</option>
              <option value="2">2 hours</option>
            </select> 
            <br><br>
                <label for="time_spent"><b>Activity Performed:</b></label>
              
                <textarea rows="0" cols="0" name = "activityPerformed" id="activity_time" placeholder="Specify the exact activity you performed">
                </textarea>
              
            <br><br>
            <label for="date"><b>Date_of_Activity:</b></label>
            <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
             <br><br>
        </div>
            <br><br>
            <button type="submit" class="submitbtn">Submit</button>
      </div>
      </div>
</form>
    <!--Gives information on sleep time--> 
<form action="hdSleep.php" method="post">
          <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
      <div class="sharedown">
        <p class="name">Sleep Time</p>
        <p onclick="shareVis('sleepShareDown')" class="sharebtn"><img src="hdsleep.png" alt="sleep image" width="150" height="150"/></p>
          <div id="sleepShareDown" class="sharedown-content">
      <p class ="activityDetail">Sleep is a crucial daily activity as it helps our body and
         mind rest and recharge. Poor sleep habits, such as staying up late or using 
         electronic devices before bed, can negatively impact our sleep quality and overall
          well-being. Good sleep habits, such as having a consistent bedtime routine and 
          avoiding caffeine, can help us get the rest we need to thrive.
      </p>
<!--Describes the detail section for sleep time-->  
      <div class = "activityDetails">
        <p>Use the tabs below to provide details of your activities today</p>
          <label for="time_of_day"><b>Time_of_Day:</b></label>
          <select name="activityTime" id="time_of_day" required>
            <option value="am">AM</option>
            <option value="pm">PM</option>
          </select>
          <br><br>
          <label for="time_spent"><b>Time_Spent:</b></label>
          <select name="activityDuration" id="time_spent" required>
          
            <option value="4">4 hours</option>
            <option value="4.5">4 hours 30 minutes</option>
            <option value="5">5 hours</option>
            <option value="5.5">5 hours 30 minutes</option>
            <option value="6">6 hours</option>
            <option value="6.5">6 hours 30 minutes</option>
            <option value="7">7 hours</option>
          </select> 
          <br><br>
          <label for="date"><b>Date_of_Activity:</b></label>
          <input type="date" id="date_of_activity" name="activityDate" value="<?php echo date('Y-m-d'); ?>" required>
           <br><br>
      </div>
          <br><br>
          <button type="submit" class="submitbtn">Submit</button>
    </div>
    </div>  
</form>       
</div>
      
    <form method="post" action="hdMood.php">
   
    <input type="hidden" name="userId"  id="userId" value="<?php echo $_SESSION['id']; ?>">
    <h3>How are you feeling? Each emoji represents your mood, select the emoji you feel reflects your mood</h3>
    <div class="mood-container">
        <div class="mood">
            <button type="submit" name="mood" value="happy">
                <p class="emoji">😃</p>
                <p class="name">Happy</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="sad">
                <p class="emoji">😔</p>
                <p class="name">Sad</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="bored">
                <p class="emoji">🥱</p>
                <p class="name">Bored</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="excited">
                <p class="emoji">🤩</p>
                <p class="name">Excited</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="angry">
                <p class="emoji">😡</p>
                <p class="name">Angry</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="afraid">
                <p class="emoji">😱</p>
                <p class="name">Afraid</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="surprise">
                <p class="emoji">😮</p>
                <p class="name">Surprise</p>
            </button>
        </div>
        <div class="mood">
            <button type="submit" name="mood" value="trust">
                <p class="emoji">🤝</p>
                <p class="name">Trust</p>
            </button>
        </div>
    </div> 

  </form>  
    



    <script>
        // Add click event listener to each emoji element
        var moodButtons = document.querySelectorAll("button[type='submit'][name^='mood']");
moodButtons.forEach(function(moodButton) {
    moodButton.addEventListener("click", function() {
        // Set the value of the hidden input field to the button's value
        document.getElementById("mood").value = moodButton.value;
        // Submit the form
        document.querySelector("form").submit();
    });
});
    </script>
    

  <!--Describes the extra  note space-->
  <div class="textarea">
  <form action="hdNote.php" method="post">
    <input type="hidden" id="userId" name="userId" value="<?php echo $_SESSION['id']; ?>">
    <p class="thoughts">Use the text box below to talk about your day. Feel free to express yourself, 
    only your social worker can see this.</p>
    <textarea rows="4" cols="50" name="note" placeholder="You can write anything you want here"></textarea>
 
              <br><br>
                      <button type="submit" class="submitbtn">Submit</button>
                    </div>
              </form>
          </div>
        
      </section>
</body>
</html>

