<?php
session_start();
// Check if user is logged in, otherwise redirect to login page
if (!isset($_SESSION["loggedin"])) {
  header("location: healthyDayLogin.html");
  exit;
}
// Include file that contains code to connect to database
include 'dbconn.php'; 
// Check if username is set in the session
if (!isset($_SESSION["username"])) {
    header("location: healthyDayLogin.html");
    exit;
}
// Get user data from database
$username = $_SESSION["username"];
$sql = "SELECT * FROM hdRegister WHERE username='$username'";
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
} else {
    die("No results found.");
}
// Assign values to variables
$username = $row["username"];
$firstName = $row["fName"];
$lastName = $row["lName"];
$dateOfBirth = $row["dob"];
$gender = $row["gender"];
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="hdayProfile.css">
    <meta charset="UTF-8" />
    <title>User Profile</title>
    
  </head>
  <body>
  <h1>The Healthy Day Platter</h1>
<!--Describes the top navigation bar--> 
            <div class="topnav">
              <a class="active" href="myHealthyDay.php">Home</a>
              <a href="hdProfile.php">My Profile</a>
              <a href="#">Records</a>
              <a href="hdlogout.php" class = "split">Logout</a>
            </div>
    <table>
     
    <img src="avatar.png" alt="https://pixabay.com/vectors/avatar-male-boy-character-1606916/" class="avatar" image width="426" height="400">
      <tr>
        <th>Username:</th>
        <td><?php echo $row["username"]; ?></td> 
      </tr>
      <tr>
        <th>First Name:</th>
        <td><?php echo $row["fName"]; ?></td>
      </tr>
      <tr>
        <th>Last Name:</th>
        <td><?php echo $row["lName"]; ?></td>
      </tr>
      <tr>
        <th>Date of birth:</th>
        <td><?php echo $row["dob"]; ?></td>
      </tr>
      <tr>
        <th>Gender:</th>
        <td><?php echo $row["gender"]; ?></td>
      </tr>  
    </table>
  </body>
</html>
