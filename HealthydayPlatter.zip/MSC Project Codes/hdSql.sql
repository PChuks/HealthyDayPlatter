CREATE TABLE IF NOT EXISTS hdRegister (
  userId int(5) NOT NULL,
  username char(10) NOT NULL,
  fName varchar(20) NOT NULL,
  lName varchar(20) DEFAULT NULL,
  dob date NOT NULL,
  homeAddress varchar(40) NOT NULL,
  postcode varchar(6) NOT NULL,
  gender varchar(8) DEFAULT NULL,
  guardianName varchar(20) NOT NULL,
  userPassword varchar(40) NOT NULL,
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;


CREATE TABLE hdFocus (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityPerformed VARCHAR(200) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdPhysical (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityPerformed VARCHAR(200) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdDowntime (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityDate DATE ,
activityPerformed VARCHAR(200) NOT NULL,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdPlay (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityPerformed VARCHAR(200) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdConnect (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityPerformed VARCHAR(200) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdTimein (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDuration VARCHAR(15) NOT NULL,
activityPerformed VARCHAR(200) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdSleep (
userId INT (5),
activityTime VARCHAR(3) NOT NULL,
activityDurationInHours VARCHAR(15) NOT NULL,
activityDate DATE ,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);

CREATE TABLE hdNote (
note VARCHAR(2000) NOT NULL,
FOREIGN KEY (userId) REFERENCES hdRegister(userId)
);
ALTER TABLE hdNote ADD COLUMN dateCreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP;


CREATE TABLE IF NOT EXISTS hdActivity (
  activityId char(5) NOT NULL,
  activityName varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
