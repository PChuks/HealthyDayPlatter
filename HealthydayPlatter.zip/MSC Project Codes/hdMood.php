<?php
//Include file that contains code to connect to database
include 'dbconn.php'; 
//
// Start the session
session_start();

// Get data from form submission
$userId = mysqli_real_escape_string($conn, $_POST["userId"]);

$emoji = mysqli_real_escape_string($conn, $_POST["mood"]);

// Build the SQL query to insert one row
$sql = "INSERT INTO hdMood (userId, emoji) VALUES ('$userId', '$emoji')";

//Insert data into database
if(mysqli_query($conn, $sql)){
    echo "<script type = 'text/javascript'> alert('Data stored in a database successfully!');
    document.location='myHealthyDay.php'</script>";
} 
//Display message if data is not captured in database
else{
    echo "ERROR: Hush! Sorry $sql. " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);






