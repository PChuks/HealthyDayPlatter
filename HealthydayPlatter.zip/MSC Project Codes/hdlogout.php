<?php
include 'dbconn.php';
session_destroy();
   header('Location:healthyDayLogin.html');
//echo'<meta http-equi = "refresh" content = "2; url=healthyDayLogin.html">';
//echo 'progress max=100<srong>rogress:60% done.</strong></progressbr><>';
echo '<span class = "itext">Logging out please wait!...</span>';
?>